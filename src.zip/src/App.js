import './App.css';
import Page1 from './pages/Dashboard/page1';
import Signin from './pages/signin/signin';
import Signup from './pages/signup/signup';
import SearchAppBar from './pages/Dashboard/p1';
import Pr1 from './components/pr1';
import NavDrawer from './components/drawer';
import Takenote3 from './pages/Dashboard/takenote3';
import { Login } from '@mui/icons-material';
function App() {
  return (
    <div className="App">
     {/* <FullWidthGrid/> */}
      {/* <OutlinedCard/> */}
      {/* <Pr1/> */}
     {/* <Signin /> */}
     <Page1 />
    </div>
  );
}

export default App;
