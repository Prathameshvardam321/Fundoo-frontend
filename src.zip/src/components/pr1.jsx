import { ClickAwayListener } from '@mui/material'
import React, { useEffect, useState, useContext } from 'react'
import axios from 'axios'

function Pr1() {
  const [color, setColor] = useState('black')
  const [state1, setState1] = useState(true)
  const [state2, setState2] = useState(false)
  const changecolor = () => {
    console.log('color');
    setColor('blue')
  }
  const handle1 = () => {
    
  }
  return (
    < >
      {/* {<div onClick={handle1} style={{ height: '30px', width: '30px', backgroundColor: 'yellow' }}>
        hellow
      </div>
      }
      {

      } */}


    </>
  )

}

export default Pr1
