import { Grid } from '@mui/material'
import React from 'react'
import '../grid/grid.css'
import OutlinedCard from '../Dashboard/note3'
function Grid1() {
  return (
    <div>
    <Grid className='grid1' container
    style={{ width: "80vw"}}
     >
    <Grid item className='gridc1'> <OutlinedCard/>    </Grid>
    <Grid item className='gridc2'> <OutlinedCard/>    </Grid>
    <Grid item className='gridc1'> <OutlinedCard/>    </Grid>
    <Grid item className='gridc1'> <OutlinedCard/>  </Grid>
    <Grid item className='gridc1'> <OutlinedCard/>  </Grid>
    <Grid item className='gridc1'> <OutlinedCard/>   </Grid>
    </Grid>
    </div>
  )
}

export default Grid1