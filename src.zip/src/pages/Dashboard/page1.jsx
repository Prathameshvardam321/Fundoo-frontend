import React, { useEffect } from 'react'
// import ColorLensOutlinedIcon from '@mui/icons-material/ColorLensOutlined';
import Typography from '@mui/material/Typography';
import MenuIcon from '@mui/icons-material/Menu';
import ArchiveOutlinedIcon from '@mui/icons-material/ArchiveOutlined';
import CardContent from '@mui/material/CardContent';
import { Delete } from '@mui/icons-material';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import TipsAndUpdatesIcon from '@mui/icons-material/TipsAndUpdates';
import RefreshIcon from '@mui/icons-material/Refresh';
import ViewStreamIcon from '@mui/icons-material/ViewStream';
import SettingsIcon from '@mui/icons-material/Settings';
import { CardActions, IconButton, styled, TextField } from '@mui/material';
import SearchAppBar from '../Dashboard/p1'
import AppsIcon from '@mui/icons-material/Apps';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import PlaylistAddCheckOutlinedIcon from '@mui/icons-material/PlaylistAddCheckOutlined';
import BrushOutlinedIcon from '@mui/icons-material/BrushOutlined';
import ImageOutlinedIcon from '@mui/icons-material/ImageOutlined';
import { getNotes } from '../../Services/dataservice';
import ColorPopper from '../../components/colorPopper';
import './pag1.css'
import { useState } from 'react';
import AddAlertRoundedIcon from '@mui/icons-material/AddAlertRounded';
import PersonAddAlt1OutlinedIcon from '@mui/icons-material/PersonAddAlt1Outlined';
import { postNotes } from '../../Services/dataservice';
import UndoIcon from '@mui/icons-material/Undo';
import RedoIcon from '@mui/icons-material/Redo';
import { ClickAwayListener } from '@mui/material';
import { Grid } from '@mui/material'
import Takenote3 from './takenote3';
import Card from '@mui/material/Card';
import DeleteIcon from '@mui/icons-material/Delete';
import { updateColor } from '../../Services/dataservice';
import { updateArchieve } from '../../Services/dataservice';
import NavDrawer from '../../components/drawer';
import {  connect } from 'react-redux';
export const DashboardContext = React.createContext()
function Page1({title}) {
  const [notes, setNotes] = useState([])
  const [isNoteFocused, setIsNoteFocused] = useState(false);
  const [takeNote, setTakeNote] = useState(true)
  const [note, setNote] = useState({ Title: "", Description: "" })
  const [color, setColor] = useState('')
  const [createNote, SetCreateNote] = useState(0)
  const [displayNav, setDisplayNav] = useState(false)
  const [drawer, setDrawer] = React.useState(false)
  const takeTitle = (event) => {
    setNote((prevState) => ({
      ...prevState, Title: event.target.value
    }))
  }
  // const listenToHeader = () => {
  //   console.log("Got msg from head");
  // }
  const takeDescription = (event) => {
    setNote((prevState) => ({
      ...prevState, Description: event.target.value
    }))
  }

  const listenToDrawer = (option) => {
    console.log(option)
    if(option === 'Notes') {
      fetch('Notes')
    }
    else if  (option === 'Archive') {
      fetch('Archive')
    } else if (option === 'Trash') {
      fetch('Trash')  
    }
  }

  

  const listenToColorPopper = (color) => {
    setColor(color)
 
  }
  useEffect(() => {
    fetch()
  }, [createNote, displayNav])
  const shift2to1 = async () => {
    let resonse = await postNotes(note)
    SetCreateNote(createNote + 1)
    console.log(resonse);
  }

  const fetch = async (option) => {
    let arrayOfAllNotes = await getNotes();
    if(option === 'Notes') {
      console.log("a")
      setNotes( arrayOfAllNotes.data.data.filter((noteObj) => noteObj.Archieve
      === false && noteObj.Trash ===false))
      console.log(arrayOfAllNotes.data.data)
    }
    else if  (option === 'Archive') {
      console.log("b")
     setNotes( arrayOfAllNotes.data.data.filter((noteObj) => noteObj.Archieve === true ))
     console.log(arrayOfAllNotes.data.data.filter((noteObj) => noteObj.Archieve === true ))
    
    } else if (option === 'Trash') {
      console.log("C")
      setNotes( arrayOfAllNotes.data.data.filter((noteObj) => noteObj.Trash === true))
      console.log(arrayOfAllNotes.data.data.filter((noteObj) => noteObj.Trash === true))
    }
    
  };

  // const fetch = async () => {
  //   let notesArray = await getNotes()
  //   setNotes(notesArray.data.data)
  //   // console.log(notesArray.data.data);
  // }




















  const changeArchieve = async ()=>{
    // let value = note['Archieve'] 
    note.Archieve = true
    await updateArchieve(note,note._id) 
    console.log(note);
  }


  // const fetch = async () => {
  //   let notesArray = await getNotes()
  //   setNotes(notesArray.data.data)
  //   console.log("Notes Array",notesArray);
  //   // console.log(notesArray.data.data);
  // }
  useEffect(() => {
    fetch('Notes')
  }, [])

  const onTextAraClick = () => {
    setIsNoteFocused(true)
    setTakeNote(false)
  }
  const handClickAway = () => {
    setIsNoteFocused(false)
    setTakeNote(true)
    SetCreateNote(createNote + 1)
  }
  
  const listenToHeader = () => {
    console.log(drawer);
    setDrawer(!drawer)
  }
  

  return (
    <>
      <DashboardContext.Provider value={()=>fetch('Notes')}>
        <div className='main'>
          <header className='keep-h1'>
            <MenuIcon className='menu' onClick={() => {
              listenToHeader()
              setDisplayNav(!displayNav)
            }} />
            <TipsAndUpdatesIcon className='bulb' />
            <div className='k-name'> {title}  </div>
            <div className='searchbar'>
              <SearchAppBar  />
            </div>
            <div className='iconRight'>
              <RefreshIcon />
              <ViewStreamIcon />
              <SettingsIcon />
            </div>
            <div className='iconCornerright'>
              <AppsIcon /> <AccountCircleIcon />
            </div>

          </header>
          <NavDrawer open= {drawer}  listenToDrawer = {listenToDrawer}  />
          <ClickAwayListener onClickAway={()=>handClickAway()}>
            <div className='notesParent' style={{ backgroundColor: color }}>
              {takeNote &&
                <div onClick={onTextAraClick} className='notes'>
                  Take a Note ...
                  <div className='notesRgt'>
                    <PlaylistAddCheckOutlinedIcon /> <BrushOutlinedIcon /> <ImageOutlinedIcon />
                  </div>
                </div>
              }
              {isNoteFocused &&
                <TextField className='notes1'
                  style={{ backgroundColor: color }}
                  onChange={takeTitle}
                  placeholder='Title ...'
                  multiline
                  maxRows={Infinity}
                  variant="standard"
                />}{
                isNoteFocused &&
                <TextField className='notes1'
                  style={{ backgroundColor: color }}
                  onChange={takeDescription}
                  placeholder='Description ...'
                  multiline
                  maxRows={Infinity}
                  variant="standard"
                />
              }
              {
                isNoteFocused &&
                <div  className='notesIconBottom' style={{display:'flex', backgroundColor: color ,justifyContent:'space-between',width:'580px' }}>
                  <AddAlertRoundedIcon /> <PersonAddAlt1OutlinedIcon />  <ColorPopper action={'create'} color={color}  listenToColorPopper={listenToColorPopper} /> <ImageOutlinedIcon />  <ArchiveOutlinedIcon onClick={changeArchieve} /> <MoreVertIcon /> <UndoIcon /> <RedoIcon /> <button style={{marginLeft:'auto'}} onClick={shift2to1}>close</button>
                </div>
              }
            </div>
          </ClickAwayListener>
          <NavDrawer /> 
        </div>
        <Grid container columnGap={5} style={{ paddingLeft: '17vw' }} >
          {notes.map((note) => <Card sx={{ maxWidth: '185px' }} variant='box2' items lg={10} md={8} sm={12} style={{ margin: '4px', borderRadius: '5px' }} >
            < Takenote3 note={note}
              Title={note.Title} Description={note.Description}
            />
          </Card>
          )
          }
        </Grid>
      </DashboardContext.Provider>
    </>
  )
}
const mapStateToProps =(state) => { return {title : state.navReducer.title} }
export default connect(mapStateToProps)(Page1)