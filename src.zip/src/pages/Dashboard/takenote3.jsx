import MenuIcon from '@mui/icons-material/Menu';
import ArchiveOutlinedIcon from '@mui/icons-material/ArchiveOutlined';
import CardContent from '@mui/material/CardContent';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import Typography from '@mui/material/Typography';
import TipsAndUpdatesIcon from '@mui/icons-material/TipsAndUpdates';
import RefreshIcon from '@mui/icons-material/Refresh';
import ViewStreamIcon from '@mui/icons-material/ViewStream';
import SettingsIcon from '@mui/icons-material/Settings';
import { CardActions, IconButton, styled, TextField } from '@mui/material';
import SearchAppBar from '../Dashboard/p1'
import AppsIcon from '@mui/icons-material/Apps';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import PlaylistAddCheckOutlinedIcon from '@mui/icons-material/PlaylistAddCheckOutlined';
import BrushOutlinedIcon from '@mui/icons-material/BrushOutlined';
import ImageOutlinedIcon from '@mui/icons-material/ImageOutlined';
import { getNotes } from '../../Services/dataservice';
import './pag1.css'
import { useContext, useEffect, useState } from 'react';
import ColorPopper from '../../components/colorPopper';
import AddAlertRoundedIcon from '@mui/icons-material/AddAlertRounded';
import PersonAddAlt1OutlinedIcon from '@mui/icons-material/PersonAddAlt1Outlined';
import ColorLensOutlinedIcon from '@mui/icons-material/ColorLensOutlined';
import React from "react";
import Card from '@mui/material/Card';
import DeleteIcon from '@mui/icons-material/Delete';
// import { updateColor } from '../../Services/dataservice';
import { deleteNotes } from '../../Services/dataservice';
import { DashboardContext } from './page1';
import { updateTrash } from '../../Services/dataservice';
// import { DashboardContext } from '../pages/Dashboard/page1';
import { updateArchieve } from '../../Services/dataservice';
import { updateColor } from '../../Services/dataservice';
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import { postNotes } from '../../Services/dataservice';
// import { updateColor } from '../../Services/dataservice';
function Takenote3(props) {
  const [state, setState] = useState(0)
  const [archive, setArchieve] = useState(true)
  const [open, setOpen] = React.useState(false);
  const [editNoteObj,setEditNoteObj] = React.useState({})
  const refresh = React.useContext(DashboardContext)
  const handleOpen = (note) => {
    setEditNoteObj({...note})
    setOpen(true);
  }
  const takeTitle = (event) => {
    setState(state + 1)
    setEditNoteObj((prevState) => ({
      ...prevState, Title: event.target.value
    }))
  }
  const takeDescription = (event) => {
    setState(state + 1)
    setEditNoteObj((prevState) => ({
      ...prevState, Description: event.target.value
    }))
  }
  const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
  };
  const handleClose = () => setOpen(false);
  const listenToColorPopper = (color) => {
    console.log(color);
  }
  useEffect(() => {
    refresh('Notes')
  }, [state])

  async function deleteCall() {
    await deleteNotes(props.note._id)
    setState(state + 1)

  }
  const shift2to1 = async () => {
    let resonse = await updateColor(editNoteObj,editNoteObj._id)
    // setEditNoteObj(resonse)
    console.log(resonse);
  }

 

  return (
    <>
      <Card style={{ border: '1px solid grey', padding: '1px', display: 'flex', flexDirection: 'column', alignItems: 'flex-start', backgroundColor: props.note.Colour }}>
      <CardContent onClick={()=>handleOpen(props.note)}>
        <Typography variant='body3' >
          {props.Title}
        </Typography>
        <br />
        {props.Description}
        <br />
        </CardContent>
        <CardActions style={{ display: 'flex', justifyContent: 'flex-end', paddingLeft: '65px', paddingTop: '10px' }}>
          <ColorPopper action={'edit'} note={props.note} listenToColorPopper={listenToColorPopper} fontSize="small" />
          {/* <DeleteIcon onClick={() => deleteCall()} /> */}
          {/* <ArchiveOutlinedIcon onClick={()=> updateArchieve1() } /> */}
          <MoreVertIcon  onClick={() => deleteCall()}  />
        </CardActions>
      </Card>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          {/* <Typography onChange={takeTitle} > */}
          <TextField onChange={takeTitle} value={editNoteObj.Title}> </TextField>
          <TextField onChange={takeDescription} value={editNoteObj.Description}> </TextField>
          <br></br>
           <button onClick={shift2to1} style={{marginLeft:'350px'}}>close</button>
        </Box>
      </Modal>
    </>
  )
}

export default Takenote3